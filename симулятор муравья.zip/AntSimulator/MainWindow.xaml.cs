﻿
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace AntSimulator
{
    public partial class MainWindow : Window
    {
        int rows;
        int columns;

        int antRow;
        int antColumn;
        int direction;

        bool[,] blackCells;

        double cellWidth;
        double cellHeight;
        int steps = 0;

        Ellipse ant;

        DispatcherTimer timer;

        public MainWindow()
        {
            InitializeComponent();

            timer = new DispatcherTimer();
            timer.Tick += Timer_Tick;

            StartButton.Click += StartButton_Click;
            PauseButton.Click += PauseButton_Click;
            ResetButton.Click += ResetButton_Click;
        }

        // Создание игрового поля
        private void GenerateButton_Click(object sender, RoutedEventArgs e)
        {
            timer.Stop();
            steps = 0;
            StepsText.Text = "Количество шагов: 0";

            if (!int.TryParse(RowsBox.Text, out rows) ||
            !int.TryParse(ColumnsBox.Text, out columns) ||
            rows < 2 || rows > 100 ||
            columns < 2 || columns > 100)
            {
                MessageBox.Show("Введите количество строк и столбцов от 2 до 100!");
                return;
            }

            GameCanvas.Children.Clear();

            blackCells = new bool[rows, columns];

            cellWidth = GameCanvas.ActualWidth / columns;
            cellHeight = GameCanvas.ActualHeight / rows;

            // Создаём клетки
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    Rectangle cell = new Rectangle();

                    cell.Width = cellWidth;
                    cell.Height = cellHeight;

                    cell.Fill = Brushes.White;
                    cell.Stroke = Brushes.Black;
                    cell.StrokeThickness = 1;

                    Canvas.SetLeft(cell, j * cellWidth);
                    Canvas.SetTop(cell, i * cellHeight);
                    steps++;
                    StepsText.Text = "Количество шагов: " + steps;

                    GameCanvas.Children.Add(cell);
                }
            }

            // Размещаем муравья в центре
            antRow = rows / 2;
            antColumn = columns / 2;

            direction = 0;

            ant = new Ellipse();

            ant.Width = cellWidth * 0.7;
            ant.Height = cellHeight * 0.7;

            ant.Fill = Brushes.Red;

            Canvas.SetLeft(ant, antColumn * cellWidth + cellWidth * 0.15);
            Canvas.SetTop(ant, antRow * cellHeight + cellHeight * 0.15);

            GameCanvas.Children.Add(ant);
        }

        // Движение муравья
        private void MoveAnt()
        {
            // Поворот и изменение цвета клетки
            if (blackCells[antRow, antColumn] == false)
            {
                direction = (direction + 1) % 4;
                blackCells[antRow, antColumn] = true;
            }
            else
            {
                direction = (direction + 3) % 4;
                blackCells[antRow, antColumn] = false;
            }

            // Изменяем цвет клетки
            foreach (UIElement element in GameCanvas.Children)
            {
                if (element is Rectangle)
                {
                    double x = Canvas.GetLeft(element);
                    double y = Canvas.GetTop(element);

                    if (Math.Abs(x - antColumn * cellWidth) < 0.1 &&
                        Math.Abs(y - antRow * cellHeight) < 0.1)
                    {
                        Rectangle cell = (Rectangle)element;

                        cell.Fill = blackCells[antRow, antColumn]
                            ? Brushes.Black : Brushes.White;

                        break;
                    }
                }
            }

            // Перемещение муравья
            switch (direction)
            {
                case 0:
                    antRow--;
                    break;

                case 1:
                    antColumn++;
                    break;

                case 2:
                    antRow++;
                    break;

                case 3:
                    antColumn--;
                    break;
            }

            // Проверяем границы поля
            if (antRow < 0 || antRow >= rows ||
                antColumn < 0 || antColumn >= columns)
            {
                timer.Stop();
                MessageBox.Show("Муравей вышел за границы поля!");
                return;
            }

            // Перемещаем муравья
            Canvas.SetLeft(ant, antColumn * cellWidth + cellWidth * 0.15);
            Canvas.SetTop(ant, antRow * cellHeight + cellHeight * 0.15);
        }

        // Запуск
        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            if (blackCells == null)
            {
                MessageBox.Show("Сначала сгенерируйте поле!");
                return;
            }

            int speed;

            if (!int.TryParse(SpeedBox.Text, out speed) ||
    speed < 10 || speed > 2000)
            {
                MessageBox.Show("Введите скорость от 10 до 2000 миллисекунд!");
                return;
            }

            timer.Interval = TimeSpan.FromMilliseconds(speed);
            timer.Start();
        }

        // Пауза
        private void PauseButton_Click(object sender, RoutedEventArgs e)
        {
            timer.Stop();
        }

        // Работа таймера
        private void Timer_Tick(object sender, EventArgs e)
        {
            MoveAnt();
        }
        // Сброс симуляции
        private void ResetButton_Click(object sender, RoutedEventArgs e)
        {
            timer.Stop();

            if (blackCells == null)
            {
                MessageBox.Show("Сначала создайте игровое поле!");
                return;
            }

            GenerateButton_Click(sender, e);
        }
    }
}
